import React from 'react'
import Header from '../../Components/Header/Header'
import './Home.css'

function Home() {
    return (
        <div className="home">
            <Header />
        </div>
    )
}

export default Home
