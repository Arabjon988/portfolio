import './App.css';
import Home from './Pages/home-page/Home';


function App() {
  return (
    <div className="app">
     <Home />
    </div>
  );
}

export default App;
